# Retail Sales Performance Analysis

## Business question
Which products, regions, and months contribute most to revenue and profit?

## Tools
Excel · SQL · Power BI

## Dataset
`retail_sales_dataset.csv` — **synthetic practice data** created for portfolio demonstration. It does not represent actual client work or a real organisation.

## Analysis workflow
1. Inspect data types, missing values, duplicates, category labels, and unusual values.
2. Use Excel to validate data and explore summary statistics.
3. Import the CSV into a SQL database and run `analysis_queries.sql`. The SQL comments state the expected table name.
4. Import the CSV into Power BI and build the suggested report.
5. Validate important totals across Excel, SQL, and Power BI.
6. Add screenshots of your finished dashboard and write evidence-based findings before publishing.

## Suggested Power BI dashboard
- Revenue, profit, units sold and orders
- Monthly revenue trend
- Revenue by product
- Profit by region
- Slicers for date, region and category

## Limitations
Synthetic practice data; results do not represent a real retailer.

## Project status
Starter project files are included. Complete and validate the dashboard, add screenshots, and replace any draft notes with your own verified findings before describing this as a finished project.
