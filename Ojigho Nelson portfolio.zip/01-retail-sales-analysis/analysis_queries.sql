-- Import the CSV into a table named retail_sales.
SELECT Product, SUM(Quantity) AS units_sold,
       ROUND(SUM(Quantity * UnitPrice), 2) AS revenue,
       ROUND(SUM(Quantity * (UnitPrice - UnitCost)), 2) AS profit
FROM retail_sales
GROUP BY Product
ORDER BY revenue DESC;

SELECT SUBSTRING(OrderDate, 1, 7) AS sales_month,
       ROUND(SUM(Quantity * UnitPrice), 2) AS revenue
FROM retail_sales
GROUP BY SUBSTRING(OrderDate, 1, 7)
ORDER BY sales_month;

SELECT Region, ROUND(SUM(Quantity * UnitPrice), 2) AS revenue
FROM retail_sales
GROUP BY Region
ORDER BY revenue DESC;
