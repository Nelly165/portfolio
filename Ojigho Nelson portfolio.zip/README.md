# OJIGHO NELSON | Data Analyst Portfolio

**Target roles:** Remote Junior Data Analyst · Reporting Analyst · BI Analyst Intern  
**Core tools:** Excel · SQL · Power BI

Welcome to my entry-level data analytics portfolio. The projects are organised around business questions, SQL analysis, and dashboard design.

> **Data transparency:** All datasets included here are synthetic practice data. They do not represent actual client work or real organisations. Complete the dashboard work and add screenshots and verified findings before presenting each project as finished.

## Projects

| Project | Business focus | Main skills |
|---|---|---|
| [01 — Retail Sales Analysis](01-retail-sales-analysis/) | Revenue, profit, products and regional trends | Data validation, aggregation, KPI reporting |
| [02 — HR Analytics](02-hr-analytics/) | Headcount and attrition patterns | Rate calculations and responsible interpretation |
| [03 — Financial Performance](03-financial-performance/) | Revenue, expenses, net profit and margin | Financial KPIs and time-series reporting |
| [04 — Inventory & Supply Chain](04-inventory-supply-chain/) | Stock levels, reorder indicators and lead times | Operational metrics and stock monitoring |

## Skills
- Excel data cleaning and validation
- SQL filtering, grouping, aggregation and KPI calculations
- Power BI dashboard planning and reporting
- Communicating findings, limitations and recommendations

## How to explore
1. Open a project folder and read its README.
2. Open the CSV in Excel or import it into your SQL database.
3. Run the SQL script after importing the CSV into the table named in the comments.
4. Build the dashboard described in the README using Power BI Desktop.
5. Add dashboard screenshots and a concise, evidence-based findings section.

## Contact
- Email: [Add your professional email]
- LinkedIn: [Add your LinkedIn profile URL]
- Power BI dashboard: [Add after publishing]
