# Hi, I'm Ojigho Nelson 👋

### Aspiring Data Analyst | Excel · SQL · Power BI

I am building practical analytics projects focused on business reporting, KPI analysis, and data visualisation.

## Featured Projects
- Retail Sales Performance Analysis
- HR Analytics: Workforce and Attrition
- Financial Performance Analysis
- Inventory and Supply Chain Analysis

## Skills
- **Excel:** data cleaning, formulas, pivot tables, charts
- **SQL:** filtering, grouping, aggregation and KPI queries
- **Power BI:** KPI cards, slicers, dashboard design and visual reporting

> All datasets in my practice portfolio are synthetic and are labelled accordingly.

## Connect
- LinkedIn: [Add your LinkedIn URL]
- Email: [Add your professional email]
- Portfolio repository: [Add repository URL]
