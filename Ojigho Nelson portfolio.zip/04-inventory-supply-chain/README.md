# Inventory and Supply Chain Analysis

## Business question
Which items may need replenishment, and how do stock levels and supplier lead times compare?

## Tools
Excel · SQL · Power BI

## Dataset
`inventory_supply_chain_dataset.csv` — **synthetic practice data** created for portfolio demonstration. It does not represent actual client work or a real organisation.

## Analysis workflow
1. Inspect data types, missing values, duplicates, category labels, and unusual values.
2. Use Excel to validate data and explore summary statistics.
3. Import the CSV into a SQL database and run `analysis_queries.sql`. The SQL comments state the expected table name.
4. Import the CSV into Power BI and build the suggested report.
5. Validate important totals across Excel, SQL, and Power BI.
6. Add screenshots of your finished dashboard and write evidence-based findings before publishing.

## Suggested Power BI dashboard
- Closing stock, inventory value and reorder SKUs
- Units sold by product
- Reorder SKUs by supplier
- Product stock-status table
- Slicers for category, supplier and stock status

## Limitations
Synthetic practice data; real replenishment decisions should consider demand forecasts and supplier reliability.

## Project status
Starter project files are included. Complete and validate the dashboard, add screenshots, and replace any draft notes with your own verified findings before describing this as a finished project.
