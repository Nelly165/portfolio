-- Import the CSV into a table named inventory_supply_chain.
SELECT Product, SUM(UnitsSold) AS units_sold,
       SUM(ClosingStock) AS closing_stock,
       SUM(CASE WHEN StockStatus = 'Reorder' THEN 1 ELSE 0 END) AS skus_needing_reorder,
       ROUND(SUM(InventoryValueNGN), 2) AS inventory_value_ngn
FROM inventory_supply_chain
GROUP BY Product
ORDER BY skus_needing_reorder DESC, units_sold DESC;

SELECT Supplier, COUNT(*) AS sku_count,
       ROUND(AVG(LeadTimeDays), 2) AS average_lead_time_days,
       SUM(CASE WHEN StockStatus = 'Reorder' THEN 1 ELSE 0 END) AS reorder_skus
FROM inventory_supply_chain
GROUP BY Supplier
ORDER BY reorder_skus DESC;
