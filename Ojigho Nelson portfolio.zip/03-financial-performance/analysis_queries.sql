-- Import the CSV into a table named financial_performance.
SELECT Year, ROUND(SUM(RevenueNGN), 2) AS revenue_ngn,
       ROUND(SUM(TotalExpensesNGN), 2) AS expenses_ngn,
       ROUND(SUM(NetProfitNGN), 2) AS net_profit_ngn,
       ROUND(100.0 * SUM(NetProfitNGN) / NULLIF(SUM(RevenueNGN), 0), 2) AS profit_margin_pct
FROM financial_performance
GROUP BY Year
ORDER BY Year;

SELECT Period, RevenueNGN, TotalExpensesNGN, NetProfitNGN, ProfitMarginPct
FROM financial_performance
ORDER BY Period;
