-- Import the CSV into a table named hr_analytics.
SELECT COUNT(*) AS headcount,
       SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) AS leavers,
       ROUND(100.0 * SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS attrition_rate_pct
FROM hr_analytics;

SELECT Department, COUNT(*) AS headcount,
       SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) AS leavers,
       ROUND(100.0 * SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS attrition_rate_pct
FROM hr_analytics
GROUP BY Department
ORDER BY attrition_rate_pct DESC;
